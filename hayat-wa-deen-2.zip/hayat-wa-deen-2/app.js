// Import functions from quran.js
const createQuranSection = window.createQuranSection;
const playAudio = window.playAudio;
document.addEventListener('DOMContentLoaded', () => {
    const mainContent = document.querySelector('.app-container');
    const menuItems = document.querySelectorAll('.menu-item');

    function showHomePage() {
        location.reload();
    }

    // وظائف عرض الأقسام المختلفة
    function showAdhkar(category) {
        const adhkarContent = document.getElementById('adhkar-content');
        adhkarContent.innerHTML = '<div class="loading">جاري التحميل...</div>';

        // مصفوفة الأذكار والأدعية
        const adhkarData = {
            'morning': [
                { text: "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لاَ إِلَـهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيْكَ لَهُ", count: 1 },
                { text: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنْ الْهَمِّ وَالْحَزَنِ", count: 3 },
                { text: "بِسْمِ اللهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلاَ فِي السَّمَاءِ", count: 3 }
            ],
            'evening': [
                { text: "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ للهِ، وَالْحَمْدُ للهِ، لاَ إِلَهَ إِلاَّ اللهُ وَحْدَهُ لاَ شَرِيكَ لَهُ", count: 1 },
                { text: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ", count: 1 }
            ],
            'prayer': [
                { text: "سُبْحَانَ رَبِّيَ الْعَظِيمِ", count: 3 },
                { text: "سُبْحَانَ رَبِّيَ الْأَعْلَى", count: 3 },
                { text: "رَبَّنَا وَلَكَ الْحَمْدُ", count: 1 }
            ],
            'sleep': [
                { text: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", count: 1 },
                { text: "اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ", count: 3 }
            ],
            'dua': [
                { text: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", count: 1 },
                { text: "اللَّهُمَّ اغْفِرْ لِي، وَارْحَمْنِي، وَاهْدِنِي، وَعَافِنِي، وَارْزُقْنِي", count: 1 }
            ],
            'hisn': [
                { text: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", count: 3 },
                { text: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ", count: 3 }
            ]
        };

        const selectedAdhkar = adhkarData[category] || [];
        const adhkarHTML = selectedAdhkar.map(dhikr => `
            <div class="dhikr-item">
                <div class="dhikr-text">${dhikr.text}</div>
                <div class="dhikr-count">التكرار: ${dhikr.count}</div>
            </div>
        `).join('');

        adhkarContent.innerHTML = adhkarHTML || '<div class="error">لا توجد أذكار متاحة لهذا القسم</div>';
    }

    function createAdhkarSection() {
        const adhkarHTML = `
            <div class="adhkar-section">
                <button id="home-button" class="home-btn">
                    <i class="fas fa-home"></i>
                    العودة للرئيسية
                </button>
                <h2>الأدعية والأذكار</h2>
                <div class="adhkar-categories">
                    <div class="category" onclick="showAdhkar('morning')">
                        <i class="fas fa-sun"></i>
                        <h3>أذكار الصباح</h3>
                    </div>
                    <div class="category" onclick="showAdhkar('evening')">
                        <i class="fas fa-moon"></i>
                        <h3>أذكار المساء</h3>
                    </div>
                    <div class="category" onclick="showAdhkar('prayer')">
                        <i class="fas fa-pray"></i>
                        <h3>أذكار الصلاة</h3>
                    </div>
                    <div class="category" onclick="showAdhkar('sleep')">
                        <i class="fas fa-bed"></i>
                        <h3>أذكار النوم</h3>
                    </div>
                    <div class="category" onclick="showAdhkar('dua')">
                        <i class="fas fa-hands-praying"></i>
                        <h3>الأدعية المأثورة</h3>
                    </div>
                    <div class="category" onclick="showAdhkar('hisn')">
                        <i class="fas fa-shield-halved"></i>
                        <h3>حصن المسلم</h3>
                    </div>
                </div>
                <div id="adhkar-content" class="adhkar-content"></div>
            </div>
        `;

        mainContent.innerHTML = adhkarHTML;
        document.getElementById('home-button').addEventListener('click', showHomePage);
    }

    function createTasbihSection() {
        const tasbihHTML = `
            <div class="tasbih-section">
                <button id="home-button" class="home-btn">
                    <i class="fas fa-home"></i>
                    العودة للرئيسية
                </button>
                <h2>السبحة الإلكترونية</h2>
                <div class="dhikr-selector">
                    <select id="dhikr-type">
                        <option value="سبحان الله">سبحان الله</option>
                        <option value="الحمد لله">الحمد لله</option>
                        <option value="لا إله إلا الله">لا إله إلا الله</option>
                        <option value="الله أكبر">الله أكبر</option>
                        <option value="أستغفر الله">أستغفر الله</option>
                    </select>
                </div>
                <div class="counter-display">
                    <span id="counter">0</span>
                </div>
                <div class="counter-buttons">
                    <button id="increment" class="counter-btn">تسبيح</button>
                    <button id="reset" class="counter-btn reset">إعادة</button>
                </div>
                <div class="target-counter">
                    <span>الهدف: </span>
                    <span id="target">33</span>
                </div>
            </div>
        `;
        mainContent.innerHTML = tasbihHTML;

        document.getElementById('home-button').addEventListener('click', showHomePage);

        let count = 0;
        const counterDisplay = document.getElementById('counter');
        const incrementBtn = document.getElementById('increment');
        const resetBtn = document.getElementById('reset');

        incrementBtn.addEventListener('click', () => {
            count++;
            counterDisplay.textContent = count;
            if (count === 33) {
                incrementBtn.classList.add('target-reached');
            }
        });

        resetBtn.addEventListener('click', () => {
            count = 0;
            counterDisplay.textContent = count;
            incrementBtn.classList.remove('target-reached');
        });
    }

    function createTasksSection() {
        const tasksHTML = `
            <div class="tasks-section">
                <button id="home-button" class="home-btn">
                    <i class="fas fa-home"></i>
                    العودة للرئيسية
                </button>
                <h2>المفكرة</h2>
                <div class="tasks-container">
                    <div class="add-task">
                        <input type="text" id="task-input" placeholder="أضف مهمة جديدة...">
                        <button id="add-task-btn">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>
                    <div id="tasks-list"></div>
                </div>
            </div>
        `;

        mainContent.innerHTML = tasksHTML;
        document.getElementById('home-button').addEventListener('click', showHomePage);

        const taskInput = document.getElementById('task-input');
        const addTaskBtn = document.getElementById('add-task-btn');
        const tasksList = document.getElementById('tasks-list');

        let tasks = JSON.parse(localStorage.getItem('tasks') || '[]');

        function renderTasks() {
            tasksList.innerHTML = tasks.map(task => `
                <div class="task-item ${task.completed ? 'completed' : ''}" data-id="${task.id}">
                    <div class="task-content">
                        <input type="checkbox" ${task.completed ? 'checked' : ''} 
                               onchange="toggleTask(${task.id})">
                        <span class="task-text">${task.text}</span>
                        <span class="task-date">${task.date}</span>
                    </div>
                    <button class="delete-task" onclick="deleteTask(${task.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `).join('');
        }

        function addTask() {
            const taskText = taskInput.value.trim();
            if (taskText) {
                const task = {
                    id: Date.now(),
                    text: taskText,
                    completed: false,
                    date: new Date().toLocaleDateString('ar-SA')
                };
                tasks.push(task);
                localStorage.setItem('tasks', JSON.stringify(tasks));
                renderTasks();
                taskInput.value = '';
            }
        }

        addTaskBtn.addEventListener('click', addTask);
        taskInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') addTask();
        });

        window.toggleTask = (taskId) => {
            tasks = tasks.map(task =>
                task.id === taskId ? {...task, completed: !task.completed} : task
            );
            localStorage.setItem('tasks', JSON.stringify(tasks));
            renderTasks();
        };

        window.deleteTask = (taskId) => {
            tasks = tasks.filter(task => task.id !== taskId);
            localStorage.setItem('tasks', JSON.stringify(tasks));
            renderTasks();
        };

        renderTasks();
    }

    // إضافة مستمعي الأحداث للقائمة الرئيسية
    menuItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            const link = this.querySelector('a');
            if (link) {
                const section = link.getAttribute('href').replace('#', '');
                console.log('Clicked section:', section);

                switch(section) {
                    case 'tasbih':
                        createTasbihSection();
                        break;
                    case 'quran':
                        createQuranSection();
                        break;
                    case 'reciters':
                        createReciterSection();
                        break;
                    case 'adhkar':
                        createAdhkarSection();
                        break;
                    case 'tasks':
                        createTasksSection();
                        break;
                    case 'qibla':
                        createQiblaSection();
                        break;
                    case 'support':
                        createSupportSection();
                        break;
                    default:
                        console.log('Section not implemented:', section);
                }
            }
        });
    });

    function createQiblaSection() {
        const qiblaHTML = `
            <div class="qibla-section">
                <button id="home-button" class="home-btn">
                    <i class="fas fa-home"></i>
                    العودة للرئيسية
                </button>
                <h2>القبلة والتقويم</h2>
                <div class="qibla-container">
                    <div class="datetime-box">
                        <div id="hijri-date"></div>
                        <div id="gregorian-date"></div>
                        <div id="current-time"></div>
                    </div>
                    <div class="compass-box">
                        <div class="compass">
                            <div class="arrow"></div>
                            <div class="qibla-direction"></div>
                        </div>
                        <div id="qibla-angle"></div>
                    </div>
                </div>
            </div>
        `;

        mainContent.innerHTML = qiblaHTML;
        document.getElementById('home-button').addEventListener('click', showHomePage);

        // تحديث التوقيت والتاريخ
        function updateDateTime() {
            const now = new Date();
            const hijriDate = new Intl.DateTimeFormat('ar-SA-u-ca-islamic', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            }).format(now);

            const gregorianDate = new Intl.DateTimeFormat('ar', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            }).format(now);

            const time = now.toLocaleTimeString('ar');

            document.getElementById('hijri-date').textContent = hijriDate;
            document.getElementById('gregorian-date').textContent = gregorianDate;
            document.getElementById('current-time').textContent = time;
        }

        // تحديث اتجاه القبلة
        function updateQiblaDirection(position) {
            const lat = position.coords.latitude;
            const lng = position.coords.longitude;
            const meccaLat = 21.4225;
            const meccaLng = 39.8262;

            const qiblaAngle = calculateQiblaDirection(lat, lng, meccaLat, meccaLng);

            // تحديث سهم القبلة
            const qiblaArrow = document.querySelector('.qibla-direction');
            if (qiblaArrow) {
                qiblaArrow.style.transform = `rotate(${qiblaAngle}deg)`;
            }

            // تحديث البوصلة
            if (window.DeviceOrientationEvent) {
                window.addEventListener('deviceorientationabsolute', function(event) {
                    if (event.alpha !== null) {
                        const compassHeading = 360 - event.alpha;
                        const compassArrow = document.querySelector('.arrow');
                        if (compassArrow) {
                            compassArrow.style.transform = `rotate(${compassHeading}deg)`;
                        }

                        // تحديث الاتجاه النهائي للقبلة بناءً على اتجاه الجهاز
                        const finalQiblaAngle = (qiblaAngle + compassHeading) % 360;
                        const qiblaAngleElement = document.getElementById('qibla-angle');
                        if (qiblaAngleElement) {
                            qiblaAngleElement.textContent = `اتجاه القبلة: ${Math.round(finalQiblaAngle)}° | المسافة: ${calculateDistance(lat, lng, meccaLat, meccaLng)} كم`;
                        }
                    }
                });
            } else {
                // في حالة عدم دعم الجهاز لحساسات التوجيه
                const qiblaAngleElement = document.getElementById('qibla-angle');
                if (qiblaAngleElement) {
                    qiblaAngleElement.textContent = `اتجاه القبلة من الشمال: ${Math.round(qiblaAngle)}°`;
                }
            }
        }

        // دالة لحساب المسافة بين نقطتين على سطح الأرض
        function calculateDistance(lat1, lon1, lat2, lon2) {
            const R = 6371; // نصف قطر الأرض بالكيلومترات
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lon2 - lon1) * Math.PI / 180;
            const a =
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLon/2) * Math.sin(dLon/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return Math.round(R * c);
        }

        function calculateQiblaDirection(lat, lng, meccaLat, meccaLng) {
            const φ1 = lat * Math.PI / 180;
            const φ2 = meccaLat * Math.PI / 180;
            const Δλ = (meccaLng - lng) * Math.PI / 180;

            const y = Math.sin(Δλ);
            const x = Math.cos(φ1) * Math.tan(φ2) - Math.sin(φ1) * Math.cos(Δλ);

            return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
        }

        // تحديث كل ثانية
        setInterval(updateDateTime, 1000);
        updateDateTime();

        // الحصول على الموقع وتحديث اتجاه القبلة
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(updateQiblaDirection);
        }
    }

    // تعريف showAdhkar كدالة عامة
    window.showAdhkar = showAdhkar;

    function createQuranSection() {
        const quranHTML = `
            <div class="quran-section">
                <button id="home-button" class="home-btn">
                    <i class="fas fa-home"></i>
                    العودة للرئيسية
                </button>
                <h2>القرآن الكريم</h2>
                <div class="surah-list" id="surah-list">
                    </div>
            </div>
        `;

        mainContent.innerHTML = quranHTML;
        document.getElementById('home-button').addEventListener('click', showHomePage);

        // تحميل السور
        fetch('https://api.alquran.cloud/v1/surah')
            .then(response => response.json())
            .then(data => {
                if (data.code === 200) {
                    const surahListHTML = data.data.map(surah => `
                        <div class="surah-item" data-number="${surah.number}">
                            <div class="surah-number">${surah.number}</div>
                            <div class="surah-name">${surah.name}</div>
                            <div class="verses-count">${surah.numberOfAyahs} آية</div>
                        </div>
                    `).join('');
                    document.getElementById('surah-list').innerHTML = surahListHTML;
                }
            })
            .catch(error => {
                document.getElementById('surah-list').innerHTML = 'عذراً، حدث خطأ في تحميل السور';
                console.error('Error:', error);
            });
    }



    function loadSurah(surahNumber) {
        fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}`)
            .then(response => response.json())
            .then(data => {
                if (data.code === 200) {
                    const surahHTML = `
                        <div class="quran-section">
                            <button id="home-button" class="home-btn">
                                <i class="fas fa-home"></i>
                                العودة للرئيسية
                            </button>
                            <h2>${data.data.name}</h2>
                            <div class="surah-content">
                                ${data.data.ayahs.map(ayah => `
                                    <div class="verse">
                                        <div class="verse-text">${ayah.text}</div>
                                        <div class="verse-number">${ayah.numberInSurah}</div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    `;
                    mainContent.innerHTML = surahHTML;
                    document.getElementById('home-button').addEventListener('click', createQuranSection);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                mainContent.innerHTML = '<div class="error">عذراً، حدث خطأ في تحميل السورة</div>';
            });
    }

    function createSupportSection() {
        const supportHTML = `
            <div class="support-section">
                <button id="home-button" class="home-btn">
                    <i class="fas fa-home"></i>
                    العودة للرئيسية
                </button>
                <h2>الدعم الفني</h2>
                <div class="support-content">
                    <div class="contact-info">
                        <h3>كيف يمكننا مساعدتك؟</h3>
                        <form id="support-form" class="support-form">
                            <input type="text" placeholder="الاسم" required>
                            <input type="email" placeholder="البريد الإلكتروني" required>
                            <textarea placeholder="رسالتك" required></textarea>
                            <button type="submit">إرسال</button>
                        </form>
                    </div>
                    <div class="developer-info">
                        <h3>معلومات عن التطبيق</h3>
                        <p class="developer-text">هذا التطبيق من تصميم وبرمجة الطالبة نورة بنت عبدالله محمد الحرير</p>
                        <p class="school-text">إهداء للمدرسة الرابعة والأربعون بالخبر</p>
                        <div class="contact-details">
                            <div class="contact-item">
                                <i class="fas fa-envelope"></i>
                                <span>alhrir@hotmail.com</span>
                            </div>
                            <div class="contact-item">
                                <i class="fas fa-phone"></i>
                                <span>0557332020</span>
                            </div>
                        </div>
                    </div>
                    <div class="faq-section">
                        <h3>الأسئلة الشائعة</h3>
                        <div class="faq-item">
                            <h4>كيف يمكنني استخدام تطبيق القرآن؟</h4>
                            <p>يمكنك اختيار السورة والقارئ المفضل لديك والاستماع مباشرة.</p>
                        </div>
                        <div class="faq-item">
                            <h4>كيف يمكنني حفظ الأذكار المفضلة؟</h4>
                            <p>يمكنك الضغط على علامة المفضلة بجانب كل ذكر لحفظه.</p>
                        </div>
                    </div>
                </div>
            </div>
        `;

        mainContent.innerHTML = supportHTML;
        document.getElementById('home-button').addEventListener('click', showHomePage);

        // معالجة نموذج الدعم
        document.getElementById('support-form')?.addEventListener('submit', function(e) {
            e.preventDefault();
            alert('تم إرسال رسالتك بنجاح. سنتواصل معك قريباً.');
            this.reset();
        });
    }

    function createReciterSection() {
        let currentAudio = null;

        const reciters = [
            // القراء المشهورين
            { id: 'shuraym', name: 'سعود الشريم', img: 'https://equran.me/assets/images/reciter/0.jpg', server: 'https://download.quranicaudio.com/quran/sa3ood_al-shuraym/' },
            { id: 'ayyub', name: 'محمد أيوب', img: 'https://equran.me/assets/images/reciter/1.jpg', server: 'https://download.quranicaudio.com/quran/muhammad_ayyoob/' },
            { id: 'luhaidan', name: 'محمد اللحيدان', img: 'https://equran.me/assets/images/reciter/2.jpg', server: 'https://download.quranicaudio.com/quran/muhammad_luhaidan/' },
            { id: 'jleel', name: 'خالد الجليل', img: 'https://equran.me/assets/images/reciter/3.jpg', server: 'https://download.quranicaudio.com/quran/khalid_al_jaleel/' },
            { id: 'afs', name: 'مشاري العفاسي', img: 'https://equran.me/assets/images/reciter/4.jpg', server: 'https://download.quranicaudio.com/quran/mishaari_raashid_al_3afaasee/' },
            { id: 'basit', name: 'عبد الباسط عبد الصمد', img: 'https://equran.me/assets/images/reciter/5.jpg', server: 'https://download.quranicaudio.com/quran/abdul_basit_murattal/' },
            { id: 'maher', name: 'ماهر المعيقلي', img: 'https://equran.me/assets/images/reciter/6.jpg', server: 'https://download.quranicaudio.com/quran/maher_al_muaiqly/' },
            { id: 'husary', name: 'محمود خليل الحصري', img: 'https://equran.me/assets/images/reciter/7.jpg', server: 'https://download.quranicaudio.com/quran/mahmood_khaleel_al-husaree/' },
            // القراء الإضافيين
            { id: 'minshawi', name: 'محمد صديق المنشاوي', img: 'https://equran.me/assets/images/reciter/8.jpg', server: 'https://download.quranicaudio.com/quran/minshawy_murattal/' },
            { id: 'sudais', name: 'عبد الرحمن السديس', img: 'https://equran.me/assets/images/reciter/9.jpg', server: 'https://download.quranicaudio.com/quran/abdurrahmaan_as-sudays/' },
            { id: 'ajm', name: 'أحمد بن علي العجمي', img: 'https://equran.me/assets/images/reciter/10.jpg', server: 'https://download.quranicaudio.com/quran/ahmed_ibn_3ali_al-3ajamy/' },
            { id: 'shatri', name: 'أبو بكر الشاطري', img: 'https://equran.me/assets/images/reciter/11.jpg', server: 'https://download.quranicaudio.com/quran/abu_bakr_ash-shaatree/' },
            { id: 'rifai', name: 'هاني الرفاعي', img: 'https://equran.me/assets/images/reciter/12.jpg', server: 'https://download.quranicaudio.com/quran/hani_ar_rifai/' },
            { id: 'ghamdi', name: 'سعد الغامدي', img: 'https://equran.me/assets/images/reciter/13.jpg', server: 'https://download.quranicaudio.com/quran/sa3d_al-ghaamidi/' }
        ];

        const surahs = [
            { number: 1, name: "الفاتحة", versesCount: 7 },
            { number: 2, name: "البقرة", versesCount: 286 },
            { number: 3, name: "آل عمران", versesCount: 200 },
            { number: 4, name: "النساء", versesCount: 176 },
            { number: 5, name: "المائدة", versesCount: 120 }
        ];


        const recitersHTML = `
            <div class="reciters-section">
                <div class="reciters-header">
                    <h2>الاستماع للقراء</h2>
                    <div class="search-box">
                        <input type="search" id="reciter-search" placeholder="ابحث عن قارئ...">
                    </div>
                <button id="home-button" class="home-btn">
                    <i class="fas fa-home"></i>
                    العودة للرئيسية
                </button>
                <h2>الاستماع للقراء</h2>
                <div class="surah-selector">
                    <select id="surah-select">
                        ${surahs.map(surah => `
                            <option value="${String(surah.number).padStart(3, '0')}">${surah.name}</option>
                        `).join('')}
                    </select>
                </div>
                <div class="reciters-list">
                    ${reciters.map(reciter => `
                        <div class="reciter-item">
                            <img src="${reciter.img}" alt="${reciter.name}">
                            <h3>${reciter.name}</h3>
                            <div class="audio-controls">
                                <button class="play-btn" data-reciter="${reciter.id}" data-server="${reciter.server}">
                                    <i class="fas fa-play"></i> استمع
                                </button>
                                <button class="stop-btn" style="display: none;">
                                    <i class="fas fa-stop"></i> إيقاف
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        mainContent.innerHTML = recitersHTML;
        document.getElementById('home-button').addEventListener('click', showHomePage);

        // إضافة مستمعي الأحداث للأزرار
        document.querySelectorAll('.play-btn').forEach(button => {
            button.addEventListener('click', function() {
                const reciterId = this.dataset.reciter;
                const serverUrl = this.dataset.server;
                const surahNumber = document.getElementById('surah-select').value;
                const audioUrl = `${serverUrl}${surahNumber}.mp3`;

                // إيقاف الصوت الحالي إذا كان يعمل
                if (currentAudio) {
                    currentAudio.pause();
                    currentAudio = null;
                    document.querySelectorAll('.play-btn').forEach(btn => {
                        btn.style.display = 'inline-block';
                        btn.nextElementSibling.style.display = 'none';
                    });
                }

                // تشغيل الصوت الجديد
                currentAudio = new Audio(audioUrl);
                currentAudio.play().catch(error => {
                    console.error('خطأ في تشغيل الصوت:', error);
                    alert('عذراً، حدث خطأ في تشغيل الصوت');
                });

                // تحديث حالة الأزرار
                this.style.display = 'none';
                this.nextElementSibling.style.display = 'inline-block';

                // إضافة مستمع لنهاية الصوت
                currentAudio.onended = () => {
                    this.style.display = 'inline-block';
                    this.nextElementSibling.style.display = 'none';
                    currentAudio = null;
                };
            });
        });

        // إضافة مستمعي الأحداث لأزرار الإيقاف
        document.querySelectorAll('.stop-btn').forEach(button => {
            button.addEventListener('click', function() {
                if (currentAudio) {
                    currentAudio.pause();
                    currentAudio = null;
                    this.style.display = 'none';
                    this.previousElementSibling.style.display = 'inline-block';
                }
            });
        });
    }
});