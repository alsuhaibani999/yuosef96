// Array of Surahs
const surahs = [
    { number: 1, name: "الفاتحة", versesCount: 7 },
    { number: 2, name: "البقرة", versesCount: 286 },
    { number: 3, name: "آل عمران", versesCount: 200 },
    { number: 4, name: "النساء", versesCount: 176 },
    { number: 5, name: "المائدة", versesCount: 120 },
    { number: 6, name: "الأنعام", versesCount: 165 },
    { number: 7, name: "الأعراف", versesCount: 206 },
    { number: 8, name: "الأنفال", versesCount: 75 },
    { number: 9, name: "التوبة", versesCount: 129 },
    { number: 10, name: "يونس", versesCount: 109 },
    { number: 11, name: "هود", versesCount: 123 },
    { number: 12, name: "يوسف", versesCount: 111 },
    { number: 13, name: "الرعد", versesCount: 43 },
    { number: 14, name: "إبراهيم", versesCount: 52 },
    { number: 15, name: "الحجر", versesCount: 99 },
    { number: 16, name: "النحل", versesCount: 128 },
    { number: 17, name: "الإسراء", versesCount: 111 },
    { number: 18, name: "الكهف", versesCount: 110 },
    { number: 19, name: "مريم", versesCount: 98 },
    { number: 20, name: "طه", versesCount: 135 },
    { number: 21, name: "الأنبياء", versesCount: 112 },
    { number: 22, name: "الحج", versesCount: 78 },
    { number: 23, name: "المؤمنون", versesCount: 118 },
    { number: 24, name: "النور", versesCount: 64 },
    { number: 25, name: "الفرقان", versesCount: 77 },
    { number: 26, name: "الشعراء", versesCount: 227 },
    { number: 27, name: "النمل", versesCount: 93 },
    { number: 28, name: "القصص", versesCount: 88 },
    { number: 29, name: "العنكبوت", versesCount: 69 },
    { number: 30, name: "الروم", versesCount: 60 },
    { number: 31, name: "لقمان", versesCount: 34 },
    { number: 32, name: "السجدة", versesCount: 30 },
    { number: 33, name: "الأحزاب", versesCount: 73 },
    { number: 34, name: "سبأ", versesCount: 54 },
    { number: 35, name: "فاطر", versesCount: 45 },
    { number: 36, name: "يس", versesCount: 83 },
    { number: 37, name: "الصافات", versesCount: 182 },
    { number: 38, name: "ص", versesCount: 88 },
    { number: 39, name: "الزمر", versesCount: 75 },
    { number: 40, name: "غافر", versesCount: 85 },
    { number: 41, name: "فصلت", versesCount: 54 },
    { number: 42, name: "الشورى", versesCount: 53 },
    { number: 43, name: "الزخرف", versesCount: 89 },
    { number: 44, name: "الدخان", versesCount: 59 },
    { number: 45, name: "الجاثية", versesCount: 37 },
    { number: 46, name: "الأحقاف", versesCount: 35 },
    { number: 47, name: "محمد", versesCount: 38 },
    { number: 48, name: "الفتح", versesCount: 29 },
    { number: 49, name: "الحجرات", versesCount: 18 },
    { number: 50, name: "ق", versesCount: 45 },
    { number: 51, name: "الذاريات", versesCount: 60 },
    { number: 52, name: "الطور", versesCount: 49 },
    { number: 53, name: "النجم", versesCount: 62 },
    { number: 54, name: "القمر", versesCount: 55 },
    { number: 55, name: "الرحمن", versesCount: 78 },
    { number: 56, name: "الواقعة", versesCount: 96 },
    { number: 57, name: "الحديد", versesCount: 29 },
    { number: 58, name: "المجادلة", versesCount: 22 },
    { number: 59, name: "الحشر", versesCount: 24 },
    { number: 60, name: "الممتحنة", versesCount: 13 },
    { number: 61, name: "الصف", versesCount: 14 },
    { number: 62, name: "الجمعة", versesCount: 11 },
    { number: 63, name: "المنافقون", versesCount: 11 },
    { number: 64, name: "التغابن", versesCount: 18 },
    { number: 65, name: "الطلاق", versesCount: 12 },
    { number: 66, name: "التحريم", versesCount: 12 },
    { number: 67, name: "الملك", versesCount: 30 },
    { number: 68, name: "القلم", versesCount: 52 },
    { number: 69, name: "الحاقة", versesCount: 52 },
    { number: 70, name: "المعارج", versesCount: 44 },
    { number: 71, name: "نوح", versesCount: 28 },
    { number: 72, name: "الجن", versesCount: 28 },
    { number: 73, name: "المزمل", versesCount: 20 },
    { number: 74, name: "المدثر", versesCount: 56 },
    { number: 75, name: "القيامة", versesCount: 40 },
    { number: 76, name: "الإنسان", versesCount: 31 },
    { number: 77, name: "المرسلات", versesCount: 50 },
    { number: 78, name: "النبأ", versesCount: 40 },
    { number: 79, name: "النازعات", versesCount: 46 },
    { number: 80, name: "عبس", versesCount: 42 },
    { number: 81, name: "التكوير", versesCount: 29 },
    { number: 82, name: "الانفطار", versesCount: 19 },
    { number: 83, name: "المطففين", versesCount: 36 },
    { number: 84, name: "الانشقاق", versesCount: 25 },
    { number: 85, name: "البروج", versesCount: 22 },
    { number: 86, name: "الطارق", versesCount: 17 },
    { number: 87, name: "الأعلى", versesCount: 19 },
    { number: 88, name: "الغاشية", versesCount: 26 },
    { number: 89, name: "الفجر", versesCount: 30 },
    { number: 90, name: "البلد", versesCount: 20 },
    { number: 91, name: "الشمس", versesCount: 15 },
    { number: 92, name: "الليل", versesCount: 21 },
    { number: 93, name: "الضحى", versesCount: 11 },
    { number: 94, name: "الشرح", versesCount: 8 },
    { number: 95, name: "التين", versesCount: 8 },
    { number: 96, name: "العلق", versesCount: 19 },
    { number: 97, name: "القدر", versesCount: 5 },
    { number: 98, name: "البينة", versesCount: 8 },
    { number: 99, name: "الزلزلة", versesCount: 8 },
    { number: 100, name: "العاديات", versesCount: 11 },
    { number: 101, name: "القارعة", versesCount: 11 },
    { number: 102, name: "التكاثر", versesCount: 8 },
    { number: 103, name: "العصر", versesCount: 3 },
    { number: 104, name: "الهمزة", versesCount: 9 },
    { number: 105, name: "الفيل", versesCount: 5 },
    { number: 106, name: "قريش", versesCount: 4 },
    { number: 107, name: "الماعون", versesCount: 7 },
    { number: 108, name: "الكوثر", versesCount: 3 },
    { number: 109, name: "الكافرون", versesCount: 6 },
    { number: 110, name: "النصر", versesCount: 3 },
    { number: 111, name: "المسد", versesCount: 5 },
    { number: 112, name: "الإخلاص", versesCount: 4 },
    { number: 113, name: "الفلق", versesCount: 5 },
    { number: 114, name: "الناس", versesCount: 6 }
];

// Make functions global (window scope)
window.fetchSurah = async function(surahNumber) {
    try {
        const response = await fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}/ar.asad`);
        if (!response.ok) {
            throw new Error(`فشل في جلب السورة: ${response.status}`);
        }

        const audioResponse = await fetch(`https://api.alquran.cloud/v1/surah/${surahNumber}/ar.alafasy`);
        if (!audioResponse.ok) {
            throw new Error(`فشل في جلب الصوت: ${audioResponse.status}`);
        }

        const data = await response.json();
        const audioData = await audioResponse.json();

        if (data.status === 'OK' && audioData.status === 'OK') {
            return {
                surah_name_ar: data.data.name,
                ayat: data.data.ayahs.map((ayah, index) => ({
                    number: ayah.numberInSurah,
                    text: ayah.text,
                    audio: audioData.data.ayahs[index].audio
                }))
            };
        }
        throw new Error('بيانات غير صالحة من API');
    } catch (error) {
        console.error('خطأ في جلب السورة:', error.message);
        alert('عذراً، حدث خطأ في جلب السورة. الرجاء المحاولة مرة أخرى لاحقاً.');
        return null;
    }
}

window.playAudio = function(audioUrl) {
    const audio = new Audio(audioUrl);
    audio.play().catch(error => {
        console.error('خطأ في تشغيل الصوت:', error);
        alert('عذراً، حدث خطأ في تشغيل الصوت');
    });
}

window.createQuranSection = function() {
    const quranHTML = `
        <div class="quran-section">
            <button id="home-button" class="home-btn">
                <i class="fas fa-home"></i>
                العودة للرئيسية
            </button>
            <h2>القرآن الكريم</h2>
            <div class="surah-list">
                ${surahs.map(surah => `
                    <div class="surah-item" data-surah="${surah.number}">
                        <span class="surah-number">${surah.number}</span>
                        <span class="surah-name">${surah.name}</span>
                        <span class="verses-count">${surah.versesCount} آية</span>
                    </div>
                `).join('')}
            </div>
            <div id="surah-content" class="surah-content"></div>
        </div>
    `;

    document.querySelector('.app-container').innerHTML = quranHTML;

    document.getElementById('home-button').addEventListener('click', () => location.reload());

    document.querySelectorAll('.surah-item').forEach(item => {
        item.addEventListener('click', async () => {
            const surahNumber = item.dataset.surah;
            const surah = await fetchSurah(surahNumber);
            if (surah) {
                displaySurah(surah);
            }
        });
    });
}

function displaySurah(surah) {
    const surahContent = document.getElementById('surah-content');
    surahContent.innerHTML = `
        <h3>${surah.surah_name_ar}</h3>
        <div class="verses">
            ${surah.ayat.map(ayah => `
                <div class="verse">
                    <span class="verse-text">${ayah.text}</span>
                    <div class="verse-controls">
                        <button class="play-btn" onclick="playAudio('${ayah.audio}')">
                            <i class="fas fa-play"></i>
                        </button>
                        <span class="verse-number">${ayah.number}</span>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}